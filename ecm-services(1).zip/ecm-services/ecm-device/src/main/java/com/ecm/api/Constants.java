package com.ecm.api;

public final class Constants {


	public static final String ADD_DEVICE_URL = "http://acs.ventus.cloud:8090/devices";
	public static final String LOGIN_URL="http://acs.ventus.cloud:8090/authentication";
	public static final String DEVICE_URL="http://acs.ventus.cloud:8090/devices?";
}
